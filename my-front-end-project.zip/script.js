function greet() {
  document.getElementById("message").textContent = "Thanks for clicking!";
}